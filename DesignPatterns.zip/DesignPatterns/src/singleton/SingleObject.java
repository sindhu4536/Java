package singleton;

public class SingleObject {
	
	//creating static instance of the class
	private static SingleObject instance = new SingleObject();
	
	//creating a private constructor so that it is not accessible by outside world
	private SingleObject(){
		
	}
	
	//get only one object available.
	public static SingleObject getInstance(){
		return instance;
	}
	
	public void showMessage(){
		System.out.println("Hello World");
	}
	

}
