package mvc;

public class MVCPatternDemo {
	
	public static void main(String args[]){
		
		Student model = getFromDataBase();
		studentView view = new studentView();
		studentController controller = new studentController(model, view);
		controller.updateView();
		controller.setStudentName("Sindhu");
		controller.updateView();
	}
	private static Student getFromDataBase(){
	      Student student = new Student();
	      student.setName("Robert");
	      student.setRollNo("10");
	      return student;
	   }

}
