package mvc;

public class Student {
	
	String RollNo;
	String Name;
	public String getRollNo() {
		return RollNo;
	}
	public void setRollNo(String RollNo) {
		this.RollNo = RollNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	

}
