package mvc;

public class studentView {
	
	public void display(String StudentName, String StudentRollno){
		System.out.println("Student Details:");
		System.out.println("Student Name :"+ StudentName);
		System.out.println("Student RollNo :"+ StudentRollno);
	}

}
