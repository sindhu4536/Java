package mvc;

public class studentController {
	
	private Student model;
	private studentView view;
	
	public studentController(Student model,studentView view){
		this.model = model;
		this.view = view;
	}
	
	public void setStudentName(String Name){
		model.setName(Name);
	}
	public void setRollNo(String RollNo){
		model.setRollNo(RollNo);
	}
	public String getStudentName(){
		return model.getName();
	}
	public String getStudentRollNo(){
		return model.getRollNo();
	}
	
	public void updateView(){
             view.display(model.getName(),model.getRollNo());
	}

}
