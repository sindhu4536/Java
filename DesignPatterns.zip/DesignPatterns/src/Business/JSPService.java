package Business;

public class JSPService implements BusinessService {
	
	public void doProcessing(){
		System.out.println("processing task by invoking JSP Service");
	}

	
	
	

}
