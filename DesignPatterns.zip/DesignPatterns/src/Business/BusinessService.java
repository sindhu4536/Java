package Business;

public interface BusinessService {

	public void doProcessing();
}
