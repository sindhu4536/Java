package Business;

public class BusinessDelegate {
	
	public BusinessLookup businessLookup = new BusinessLookup();
	public BusinessService businessService;
	public String serviceType;
	
	public void setServiceType(String serviceType){
		this.serviceType = serviceType;
	}
	
	public void doTask(){
		businessService = businessLookup.getBusinessService(serviceType);
		businessService.doProcessing();
	}

}
