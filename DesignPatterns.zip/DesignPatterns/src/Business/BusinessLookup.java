package Business;

public class BusinessLookup {
	
	public BusinessService getBusinessService(String ServiceType){
		if(ServiceType.equalsIgnoreCase("EJB")){
			return new EJBService();
		}
		
		else{
			return new JSPService();
		}
	}

}
