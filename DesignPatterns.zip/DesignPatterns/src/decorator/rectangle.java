package decorator;

public class rectangle implements shape {
	
	public void draw(){
		System.out.println("rectangle :: draw()");
	}

}
