package decorator;

public class circle implements shape {

	public void draw(){
		System.out.println("circle : : draw");
	}
}
