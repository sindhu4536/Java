package decorator;

public class redshapeDecorator extends shapeDecorator{
	
	public redshapeDecorator(shape decoratedShape){
		super(decoratedShape);
	}
	
	public void draw(shape decoratedShape){
		decoratedShape.draw();
		setRedBorder(decoratedShape);
	}
	
	public void setRedBorder(shape decoratedShape){
		System.out.println(" set red color border");
	}

}
