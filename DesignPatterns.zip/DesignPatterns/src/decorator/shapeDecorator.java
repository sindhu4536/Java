package decorator;

public class shapeDecorator implements shape{
	
	protected shape decoratedShape;
	
	public shapeDecorator(shape decoratedShape){
		this.decoratedShape = decoratedShape;
	}
	
	public void draw(){
		decoratedShape.draw();
		
	}

}
