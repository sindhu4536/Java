package decorator;

public interface shape {
	
	public void draw();

}
