package decorator;

public class DecoratorPattern {
	
	public static void main(String[] args) {

	      shape circle = new circle();

	      shape redCircle = new redshapeDecorator(new circle());

	      shape redRectangle = new redshapeDecorator(new rectangle());
	      System.out.println("Circle with normal border");
	      circle.draw();

	      System.out.println("\nCircle of red border");
	      redCircle.draw();

	      System.out.println("\nRectangle of red border");
	      redRectangle.draw();
	   }

}
