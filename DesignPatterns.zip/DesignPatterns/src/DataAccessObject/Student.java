package DataAccessObject;

public class Student {
	
	int RollNo;
	String Name;
	public Student(String Name,int RollNo){
		this.Name = Name;
		this.RollNo = RollNo;
	}
	public int getRollNo() {
		return RollNo;
	}
	public void setRollNo(int RollNo) {
		this.RollNo = RollNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	

}
