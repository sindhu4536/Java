package DataAccessObject;
import java.util.*;

public class StudentDaoImp implements StudentDao {
	
	//List acts as the Database
	List<Student> Students;
	
	public StudentDaoImp(){
		Students = new ArrayList<Student>();
		Student student1 = new Student("Sindhu",0);
		Student student2 = new Student("Sindhuja",1);
		Students.add(student1);
		Students.add(student2);
		}
	public void deleteStudent(Student student){
		Students.remove(student.getRollNo());
		System.out.println("Student Roll No:" +student.getRollNo() +"deleted from database");
	}
	
	//retrieve list of students from database
	public List<Student> getAllStudents(){
		return Students;
	}
	
	public Student getStudent(int RollNo){
		return Students.get(RollNo);
	}
	public void updateStudent(Student student) {
	      Students.get(student.getRollNo()).setName(student.getName());
	      System.out.println("Student: Roll No " + student.getRollNo() + ", updated in the database");
	   }
	

}
