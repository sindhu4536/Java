package proxy;

public class ProxyPattern {
	
	public static void main(String[] args) {
	      Image image = new ProxyImage("test_10mb.jpg");

	      //image will be loaded from disk
	      //RelaImage object is initialized and called 
	      image.display(); 
	      System.out.println("");
	      
	      //image will not be loaded from disk
	      // only the display method of realImage is called
	      image.display(); 	
	   }

}
