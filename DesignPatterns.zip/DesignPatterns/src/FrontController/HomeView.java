package FrontController;

public class HomeView {
	
	public void display(){
		System.out.println(" Dislaying the Home Page");
	}

}
