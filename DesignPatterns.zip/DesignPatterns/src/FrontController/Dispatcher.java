package FrontController;

public class Dispatcher {
	
	private StudentView studentview;
	private HomeView homeview;
	
	public Dispatcher(){
		studentview = new StudentView();
		homeview = new HomeView();
	}
	
	public void dispatch(String request){
		if(request.equalsIgnoreCase("STUDENT")){
			studentview.display();
		}
		else{
			homeview.display();
		}
	}

}
