package FrontController;

public class StudentView {
	
	public void display(){
		
		System.out.println("Displaying the Student Page");
	}

}
