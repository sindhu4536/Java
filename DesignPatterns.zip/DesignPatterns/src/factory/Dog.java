package factory;

public interface Dog {
	
	public void speak();
}
