package factory;

/*The calling factory have a method of telling the factory what it wants and factory method
 * makes the decision*/

public class JavaFactoryPattern {

	public static void main(String args[]){
		
		Dog dog = DogFactory.getDog("small");
		dog.speak();
		
		dog = DogFactory.getDog("large");
		dog.speak();
		
		
	}
}
