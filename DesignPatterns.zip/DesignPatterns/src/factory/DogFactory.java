package factory;
/*Dog factory class which implements the getDog() method which returns
 * the particular type of dog depending on the criteria of the dog*/
class DogFactory{
	
public static Dog getDog(String criteria) {

	if(criteria.equals("small"))
		return new Ponny();
	else if(criteria.equals("big"))
		return new Tonny();

	return null;
}

}
