package factory;

public class Ponny implements Dog{
	
	public void speak(){
		System.out.println("My name is ponny");
	}

}
