package factory;

public class Tonny implements Dog {
	
	public void speak(){
		System.out.println("My name is Tonny");
	}

}
