package facade;

public class square implements shape {
	
	public void draw(){
		System.out.println("square :: draw()");
		
	}

}
