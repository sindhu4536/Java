package facade;

public class shapeMaker {
	
	private shape circle;
	private shape rectangle;
	private shape square;
	
	// constructor to create the objects
	
	public shapeMaker(){
	     circle = new circle();
		 rectangle = new rectangle();
		 square = new square();
		}
	
	public void drawCircle(){
		circle.draw();
	}
	public void drawRectangle(){
		rectangle.draw();
	}
	public void drawSquare(){
		square.draw();
	}

}
