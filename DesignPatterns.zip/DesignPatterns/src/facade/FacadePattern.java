package facade;

public class FacadePattern {

	public static void main(String args[]){
		
		shapeMaker maker = new shapeMaker();
		maker.drawCircle();
		maker.drawRectangle();
		maker.drawSquare();
		
	}
}
