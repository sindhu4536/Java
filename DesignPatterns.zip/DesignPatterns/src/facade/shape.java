package facade;

public interface shape {
	
	public void draw();

}
