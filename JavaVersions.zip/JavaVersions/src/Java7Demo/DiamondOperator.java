package Java7Demo;

import java.util.HashMap;
import java.util.Map;

public class DiamondOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Integer> students = new HashMap<>();
		 students.put("harika",1);
		 students.put("sindhu",2);
		 students.put("mounika",3);
		 
		 System.out.println("values in hashmap");
	        for (Map.Entry<String,Integer> me : students.entrySet()) {
	          System.out.println("Key: "+me.getKey() + " & Value: " + me.getValue());
	        }
		

	}

}
