package Java7Demo;

import java.util.Scanner;

public class StringSwitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your choice:");
		String choice = scanner.next();
		switch(choice){
		case "Apple":
			System.out.println("I am Apple");
			break;
		case "Mango":
			System.out.println("I am mango");
			break;
		case "Banana":
			System.out.println("I am Banana");
			break;
		default:
			System.out.println("I am a fruit");
		}
		
		scanner.close();

	}

}
