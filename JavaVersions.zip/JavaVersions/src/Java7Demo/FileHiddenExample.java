package Java7Demo;

import java.io.File;
import java.io.IOException;

public class FileHiddenExample {

	public static void main(String[] args)throws SecurityException,IOException {
		
		// TODO Auto-generated method stub
		File file = new File("C:/Users/sindhu/Desktop/documents/Students.txt");
		if(file.isHidden()){
			System.out.println("The file is hidden");
		}else{
			System.out.println("The file is not hidden");
		}

	}

}
