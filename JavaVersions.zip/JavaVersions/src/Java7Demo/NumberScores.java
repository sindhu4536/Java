package Java7Demo;

public class NumberScores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1_000;
		int b = 2_000;
		System.out.println("Display the sum of numbers:"+(a+b));

	}

}
