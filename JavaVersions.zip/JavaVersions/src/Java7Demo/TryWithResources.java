package Java7Demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryWithResources {

	public static void main(String[] args) {

		try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/sindhu/Desktop/documents/Students.txt")))
		{

			String line;

			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} 

	}
}