package Java7Demo;

public class MultiCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int arr[] = new int[2];
		arr[0] = 10;
		arr[1] = 20;
		int res =0;
		
		try{
		    res = a/0;
			arr[0] = 30;
		}catch(ArithmeticException | ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}
		
	    System.out.println(res);
		
		

	}

}
