package Java8Demo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class PeriodDuration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PeriodDuration duration = new PeriodDuration();
		duration.testPeriod();
		duration.testDuration();

	}
	public void testPeriod(){
		LocalDate date1 = LocalDate.now();
		System.out.println("current date: "+date1);
		
		LocalDate date2 = date1.plus(1,ChronoUnit.MONTHS);
		System.out.println("Date after one month:"+date2);
		
		Period period = Period.between(date1,date2);
		System.out.println("Period :"+period);
		
	}
	
	public void testDuration(){
		  LocalTime time1 = LocalTime.now();
	      Duration twoHours = Duration.ofHours(2);
			
	      LocalTime time2 = time1.plus(twoHours);
	      Duration duration = Duration.between(time1, time2);
			
	      System.out.println("Duration: " + duration);
	}

}
