package Java8Demo;

public class LambdaExpression {
	
	/* Lambda expressions facilitates functional programming.A lambda expression can be passed
	 *  if it was an object and can be executed on demand. 
	*/

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LambdaExpression expression = new LambdaExpression();
		//Declaring the type
		MathOperation Addition = (int a,int b)-> a + b;
		
		//Without declaring the type
		MathOperation Substraction = (a,b)->a-b;
		
		//With return statement along with curly braces
		MathOperation Multiplication = (int a, int b) -> { return a * b; };
		
	    //without return statement and without curly braces
	    MathOperation division = (int a, int b) -> a / b;
	    
	    System.out.println("10+5="+ expression.operate(10,5,Addition));
	    System.out.println("10-5="+expression.operate(10,5,Substraction));
	    System.out.println("10*5="+expression.operate(10,5,Multiplication));
	    System.out.println("10/5="+expression.operate(10,5,division));
	    
	    //without paranthesis
	    GreetingService greeting1 = message ->
	    System.out.println("Hello "+message);
	    
	    //with paranthesis
	    GreetingService greeting2 = (message)->
	    System.out.println("Hello "+message);
	    
	    greeting1.sayMessage("sindhu");
	    greeting2.sayMessage("mounika");
	    
	}
	interface MathOperation{
		int operation(int a ,int b);
	}
	interface GreetingService{
       void sayMessage(String message);
	}
	private int operate(int a,int b,MathOperation mathoperation){
		return mathoperation.operation(a,b);
	}

}
