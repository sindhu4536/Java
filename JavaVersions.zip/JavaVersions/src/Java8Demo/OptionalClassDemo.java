package Java8Demo;

import java.util.Optional;

public class OptionalClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OptionalClassDemo demo = new OptionalClassDemo();
		Integer value1 = null;
		Integer value2 = new Integer(10);
		
		//ofNullable - allows passed parameter to be null
		Optional<Integer> a = Optional.ofNullable(value1);
		
		//of-throws null pointer exception if the passed value is null
		Optional<Integer> b = Optional.of(value2);
		
		System.out.println(demo.sum(a,b));
		
	}
	
	public Integer sum(Optional<Integer> a,Optional<Integer> b){
		System.out.println("First parameter:"+ a.isPresent());
		System.out.println("Second paramerer:"+b.isPresent());
		
		//orElse-returns the value present or returns the value passed
		Integer value1 = a.orElse(0);
		Integer value2 = b.get();
		
		return value1+value2;
		
	}

}
