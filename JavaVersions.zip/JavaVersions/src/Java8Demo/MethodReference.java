package Java8Demo;

import java.util.ArrayList;
import java.util.List;

public class MethodReference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> names = new ArrayList<String>();
		
		names.add("sindhu");
		names.add("harika");
		names.add("mounika");
		
		names.forEach(System.out::println);
	}

}
