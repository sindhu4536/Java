package Java8Demo;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;


public class TestAdjustersDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        TestAdjustersDemo demo = new TestAdjustersDemo();
        demo.testAdjusters();
	}
	
	public void testAdjusters(){
		LocalDate date1 = LocalDate.now();
		System.out.println("current date:"+date1);
		
		LocalDate nextTuesday = date1.with(TemporalAdjusters.next(DayOfWeek.TUESDAY));
		System.out.println("Next tuesday is:"+nextTuesday);
		
		  //get the second saturday of next month
	      LocalDate firstInYear = LocalDate.of(date1.getYear(),date1.getMonth(), 1);
	      LocalDate secondSaturday = firstInYear.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY)).with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
	      System.out.println("Second Saturday on : " + secondSaturday);
		
		
	}

}
