package Java5Demo;

class return1{
	return1 get(){
		return this;
	}
}

public class CovariantReturn extends return1 {

	CovariantReturn get(){
		return this;
	}
	
	void message(){
		System.out.println("covariant message");
	}
	
	public static void main(String args[]){
		new CovariantReturn().get().message();
		
	}
}
