package Java5Demo;

public class VariableArgs {
	
	static int addTest(String message,int... numbers){
		System.out.println(message);
		int sum = 0;
		for(int n : numbers){
			sum += n;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(VariableArgs.addTest("sum of two numbers", 10,12));
		System.out.println(VariableArgs.addTest("sum of three numbers",10,11,12));
		System.out.println(VariableArgs.addTest("sum of four numbers",10,20,25,30));
		 

	}

}
