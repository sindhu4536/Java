package Java5Demo;

enum directions{
	EAST,WEST,SOUTH,NORTH;
}

public class EnumDemo {

	public String Selection(directions direction){
		String choice="";
		if(direction.equals(directions.EAST)){
			choice = "east";
		}else if(direction.equals(directions.WEST)){
			choice="west";
		}else if(direction.equals(directions.NORTH)){
			choice ="north";
		}else if(direction.equals(directions.SOUTH)){
			choice="south";
		}
		
		return choice;
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		directions[] direction = directions.values();
		for(directions direct:direction){
			System.out.println(direct.toString() + ": Oridinal Value->" + direct.ordinal());

		}
		
	}

}
