package Java5Demo;

public class AutoBoxUnBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;
		Integer a = new Integer(x);//autoboxing
		System.out.println(a);
		Integer b = new Integer(100);
		int y = b;//unboxing
        System.out.println(y);		

	}

}
