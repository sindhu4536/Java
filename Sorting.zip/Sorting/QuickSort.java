package Sorting;

import java.util.*;

public class QuickSort {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int n = sc.nextInt();
		int[] array = new int[n];
		System.out.println("enter the elements of the array:");
		for (int i = 0; i < n; i++) {
			array[i] = sc.nextInt();
		}

		quicksort(array, 0, array.length);
		print(array, 0, array.length);
		sc.close();
	}

	/**
	 * The given array is partioned and the process is repeated
	 * 
	 * @param arr
	 * @param left
	 * @param right
	 */
	public static void quicksort(int[] arr, int left, int right) {
		if (right - left >= 2) {
			int pivot = partition(arr, left, right);
			// print(arr,0,arr.length);
			quicksort(arr, left, pivot);
			quicksort(arr, pivot + 1, right);
		}

	}

	/**
	 * pivot is considered as the last element and the array is partitioned
	 * based on the pivot element
	 * 
	 * @param arr
	 * @param left
	 * @param right
	 * @return
	 */
	public static int partition(int[] arr, int left, int right) {
		int x = arr[right - 1];//pivot element
		int i = -1;
		for (int j = 0; j <= right - 2; j++) {
			if (arr[j] < x) {
				i = i + 1;
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		//swaping the pivot element.
		int temp1 = arr[i + 1];
		arr[i + 1] = arr[right - 1];
		arr[right - 1] = temp1;

		return i + 1;

	}

	public static void print(int[] array, int left, int right) {
		for (int i = left; i < right; ++i) {
			prints(array[i]);
		}
		System.out.println("");
	}

	public static void prints(int element) {
		System.out.print(Integer.toString(element) + " ");
	}
}
