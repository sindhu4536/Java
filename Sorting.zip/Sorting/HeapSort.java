package Sorting;
import java.util.*;
public class HeapSort {
	/*/
	 * Heap Sort is implemented using the heap data structure
	 * A heap structure is a rooted binary tree
	 * main operations are build maxheap and then maxheapify
	 */
	public static int N;
	public static void heapsort(int[] arr){
		BuildMaxHeap(arr);
		for(int i=N;i>0;i--){
			swap(arr,0,i);
			N=N-1;
			//max heapify the array 
			Maxheapify(arr,0);
		}
	}
	/**
	 * To construct the max-heap on the given numbers in the array
	 * @param arr
	 */
   public static  void BuildMaxHeap(int[] arr){
	   N= arr.length-1;
	   for(int i=N/2;i>=0;i--){
		    Maxheapify(arr,i);
	   }
   }
   /**
    * To maintain the order of keys after each operation we need to 
    * perform the heapify operation either it is max-heap or min-heap
    * @param arr
    * @param index
    */
   public static void  Maxheapify(int[] arr,int index){
	   
	   int left = 2*index;
	   int right = (2*index)+1;
	   int max =index;
	   if(left<=N && arr[left]>arr[index]){
		   max = left;
	   }
	   if(right <= N && arr[right] > arr[max]){
		   max = right;
	   }
	   if(max!=index){
		   swap(arr,index,max);
		   Maxheapify(arr,max);
	   }
   }
   public static void swap(int arr[], int i, int j)
   {
       int tmp = arr[i];
       arr[i] = arr[j];
       arr[j] = tmp; 
   }   
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array:");
		int n = sc.nextInt();
		int[] array = new int[n];
		System.out.println("enter the elements of array:");
		for(int i=0;i<n;i++){
			array[i] = sc.nextInt();
		}

		heapsort(array);
		System.out.println("Array after sorting:");
		for(int i=0;i<n;i++){
			System.out.print(array[i]+" ");
		}
		System.out.println();
		sc.close();
	}

}
