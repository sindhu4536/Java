package Sorting;

import java.io.*;

public class Selection {

	public static void main(String args[]) throws IOException {
		InputStreamReader obj = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(obj);
		System.out.println("number of elements:");
		int n = Integer.parseInt(br.readLine());
		int numbers[] = new int[n];

		int minimum;
		
		/*Array is imaginarily divided into sorted and unsorted array
		 *For every step the number of elements in the unsorted array
		 *decreases by one i.e for every step we get one sorted element
		 */
		
		for (int i = 0; i < n; i++) {
			System.out.println("Enter number:");
			numbers[i] = Integer.parseInt(br.readLine());
		}

		for (int i = 0; i < numbers.length; i++) {
			minimum = i;

			for (int j = i + 1; j < numbers.length; j++) {
				if (numbers[j] < numbers[minimum]) {
					minimum = j;
				}
			}

			if (minimum != i) {
				int temp = numbers[minimum];
				numbers[minimum] = numbers[i];
				numbers[i] = temp;

			}
		}

		System.out.println("sorted array :");
		for (int k = 0; k < numbers.length; k++) {
			System.out.println(numbers[k]);
		}

	}

}
