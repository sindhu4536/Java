package Sorting;
import java.util.*;
public class CountingSort {
	
	private static int[] counting(int[] arr,int k){
		int[] count = new int[k];
		//count the number of elements for each i
		for(int i=0;i<arr.length;i++){
			int num = arr[i];
			count[num] = count[num] +1;
		}
		int[] array = new int[arr.length];
		
		//count[0] remains the same
		for(int i=1;i<k;i++){
			count[i] = count[i]+count[i-1];
		}
		for(int i= arr.length-1;i>=0;i--){
			int number = arr[i];
			array[--count[number]] = number;
			
		}
		return array;
	}

	public static void main(String args[]){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of the array:");
		int n = scanner.nextInt();
		System.out.println("Enter the range of numbers:");
		int k = scanner.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter the elements of the array:");
		for(int i=0;i<n;i++){
			arr[i] = scanner.nextInt();
		}
		int[]  result = counting(arr,k);
		
		for(int x=0;x<result.length;x++){
			System.out.print(result[x]+" ");
		}
		scanner.close();
	}
}
