package Sorting;

import java.io.*;

public class MergeSort {

	private int[] merge;
	private int[] numbers;
	private int length;

	/**
	 * divide the array into parts then sort them and merge them
	 * @param first
	 * @param last
	 */
	public void mergeSort(int first, int last) {
		if (first < last) {
			int middle = first + (last - first) / 2;
			mergeSort(first, middle);
			mergeSort(middle + 1, last);
			merge(first, middle, last);

		}
	}
	/**
	 * merge the sorted arrays and form the final sorted array
	 * @param first
	 * @param middle
	 * @param last
	 */

	public void merge(int first, int middle, int last) {
		for (int i = first; i <= last; i++) {
			merge[i] = numbers[i];
			System.out.print(merge[i] + " ");

		}
		System.out.print("\n");

		int i = first;
		int j = middle + 1;
		int k = first;
		while (i <= middle && j <= last) {
			if (merge[i] < merge[j]) {
				numbers[k] = merge[i];
				i++;
			} else {
				numbers[k] = merge[j];
				j++;
			}
			k++;
		}
		while (i <= middle) {
			numbers[k] = merge[i];
			k++;
			i++;
		}
		while (j <= last) {
			numbers[k] = merge[j];
			k++;
			j++;
		}
		for (int l = first; l <= last; l++) {
			System.out.print(numbers[l] + " ");
		}
		System.out.print("\n");

	}

	public static void main(String args[]) throws IOException {
		int[] input = { 6, 9, 2, 4, 1, 5, 3, 8, 0 };
		MergeSort d = new MergeSort();
		d.sort(input);
		for (int i : input) {
			System.out.print(i);
			System.out.print(" ");
		}

	}

	public void sort(int[] input) {
		this.numbers = input;
		this.length = input.length;
		this.merge = new int[length];
		mergeSort(0, input.length - 1);
	}
}