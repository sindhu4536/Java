package Sorting;

import java.io.*;
import java.util.*;

public class BubbleSort {

	public static void main(String args[]) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("number of elements:");
		int n = sc.nextInt();
		int numbers[] = new int[n];
		int j = 0;
		boolean swap = true;
		int temp;
		System.out.println("Enter the elements of the array");
		for (int i = 0; i < n; i++) {
			numbers[i] = sc.nextInt();

		}

		/* adjacent elements are compared and swapped for each iteration 
		 * complexity of bubble sort is O(n^2)*/
		while(swap){
			swap = false;
			j++;
			for(int i=0;i<numbers.length-j;i++){
				if(numbers[i]>numbers[i+1]){
					temp = numbers[i];
					numbers[i] = numbers[i+1];
					numbers[i+1] = temp;
					swap = true;
				}
			}
		}
		System.out.println("Sorted array is:");
		for (int k = 0; k < numbers.length; k++) {
			System.out.print(numbers[k] + " ");
		}
		sc.close();
	}

}
